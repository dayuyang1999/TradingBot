from .data import get_data

__all__ = ['get_data']